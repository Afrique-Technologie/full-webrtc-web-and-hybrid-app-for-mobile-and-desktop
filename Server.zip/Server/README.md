# live-stream-webrtc-server

The client: https://github.com/sieuhuflit/react-native-live-stream-webrtc-example

Demo page: https://live-stream-webrtc-server.herokuapp.com

# Get started

1.  `npm install`
2.  `node app.js`
